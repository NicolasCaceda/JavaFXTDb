package HSCode;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

public class Controller {

  private dbHandler db = null;

  @FXML
  public Button NextButton;

  @FXML
  public Button PrevButton;

  @FXML
  public Button RandomButton;

  @FXML
  private HBox Secret;
  private Image secretImage = new Image ("file:Images/Hearthstone-Logo.png", 200,
      200, true, true);

  @FXML
  public Button Jaina;
  private Image jainaPortrait = new Image("file:Images/Jaina.jpg",64.53125,
      31,true,true);

  @FXML
  public Button Uther;
  private Image utherPortrait = new Image("file:Images/Uther.jpg", 64.53125,
      31,true,true);

  @FXML
  public Button Rexxar;
  private Image rexxarPortrait = new Image("file:Images/Rexxar.jpg",64.53125,
      31,true,true);

  @FXML
  public Button Valeera;
  private Image valeeraPortrait = new Image("file:Images/Valeera.jpg",64.53125,
      31,true,true);

  @FXML
  public void initialize(){
    Jaina.setGraphic(new ImageView(jainaPortrait));
    Uther.setGraphic(new ImageView(utherPortrait));
    Rexxar.setGraphic(new ImageView(rexxarPortrait));
    Valeera.setGraphic(new ImageView(valeeraPortrait));
    Secret.getChildren().add(new ImageView(secretImage));
    db = new dbHandler();
  }

  @FXML
  void getHunter() throws Exception{
    db.getHunterSecrets();
    Secret.getChildren().clear();
    Secret.getChildren().add(new ImageView(rexxarPortrait));
  };

  @FXML
  void getMage() throws Exception{
    db.getMageSecrets();
    Secret.getChildren().clear();
    Secret.getChildren().add(new ImageView(jainaPortrait));
  };

  @FXML
  void getPaladin() throws Exception{
    db.getPaladinSecrets();
    Secret.getChildren().clear();
    Secret.getChildren().add(new ImageView(utherPortrait));
  };

  @FXML
  void getRogue() throws Exception{
    db.getRogueSecrets();
    Secret.getChildren().clear();
    Secret.getChildren().add(new ImageView(valeeraPortrait));
  };

  @FXML
  void next() throws Exception{
    Secret.getChildren().clear();
    Secret.getChildren().add(new ImageView(new Image("file:Images/Secrets/"
        + db.nextCard() + ".png", 200, 200, true, true)));
  }

}
